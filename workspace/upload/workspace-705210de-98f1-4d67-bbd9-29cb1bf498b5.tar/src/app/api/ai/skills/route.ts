import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface SkillsBody {
  jobTitle?: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as SkillsBody;
    const jobTitle = body.jobTitle?.trim();

    if (!jobTitle) {
      return NextResponse.json(
        { error: "Job title is required" },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: "assistant",
          content:
            "You are a technical recruiter and career advisor. Given a target job title, recommend the most relevant skills for a resume. Return a JSON object with two keys: \"technical\" (array of up to 8 technical/programming skills) and \"soft\" (array of up to 4 soft skills). Respond with ONLY the JSON object, no markdown, no explanation, no code fences.",
        },
        {
          role: "user",
          content: `Target job title: "${jobTitle}". Recommend the most relevant technical and soft skills.`,
        },
      ],
      thinking: { type: "disabled" },
    });

    const raw = completion.choices[0]?.message?.content?.trim() ?? "";

    let parsed: { technical: string[]; soft: string[] };
    try {
      const cleaned = raw
        .replace(/^```(?:json)?/i, "")
        .replace(/```$/i, "")
        .trim();
      parsed = JSON.parse(cleaned);
    } catch {
      // Fallback: split by lines/commas if JSON parse fails
      const lines = raw
        .split(/[\n,•]/)
        .map((s) => s.replace(/^[-*\d.\s)]+/, "").trim())
        .filter(Boolean);
      parsed = { technical: lines.slice(0, 8), soft: lines.slice(8, 12) };
    }

    const technical = Array.isArray(parsed.technical)
      ? parsed.technical.filter((s) => typeof s === "string").slice(0, 8)
      : [];
    const soft = Array.isArray(parsed.soft)
      ? parsed.soft.filter((s) => typeof s === "string").slice(0, 4)
      : [];

    return NextResponse.json({ technical, soft });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
